$("document").ready(function(){
    // THis document above, is refer to all document in this JQ. Make use of the ready in your javascript and Jquery.




//  $("#date").datepicker();
















})
